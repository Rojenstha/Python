def area_circle(r):
    area=3.14*r*r
    return area
x=int(input("Enter the radius:"))
print("The radius is", area_circle(x))
