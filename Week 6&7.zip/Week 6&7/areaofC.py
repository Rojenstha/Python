r= int(input("Enter the radius of Circle:"))
pi= 3.14
area= pi*r*r
print("The area of circle is ",area)
