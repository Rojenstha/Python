num= input("Enter A, B, C:")
if num=="A" or num=="B" or num=="C":
  if num=="A":
    print("Apple")
  if num=="B":
    print("Banana")
  if num=="C":
    print("Coconut")
else:
    print("Wrong")
