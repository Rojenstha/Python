num= input("Enter A, B, C:")
if num=="A":
    print("Apple")
elif num=="B":
    print("Banana")
elif num=="C":
    print("Coconut")
