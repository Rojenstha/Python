fname= input("Enter your first name:")
lname= input("Enter your last name:")
add= input("Enter your address:")
print("Your full name is ",fname,lname,".","Your Address is ",add)
