a=10
b=3
print("The sum is",a+b)
print("The product is ",a*b)
