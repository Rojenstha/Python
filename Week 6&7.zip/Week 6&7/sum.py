a=5
b=6
sum=a+b
print("The sum is",sum)
