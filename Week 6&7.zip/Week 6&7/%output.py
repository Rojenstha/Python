name=input("Enter the name:")
age= int(input("Enter the age:"))
add= input("Enter the address:")
print("The name is %s.The age is %d.The address is %s."%(name,age,add))
