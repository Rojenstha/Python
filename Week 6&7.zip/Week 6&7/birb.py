p = 25
b = 15
h=((p**2)+(b**2))**(1/2)
print("The distance between bird and observer is ",h)
