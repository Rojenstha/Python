a="rojen"
b="shrestha"
fullname=a+" "+b
print(fullname)
print(a,b)
