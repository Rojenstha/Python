def area_rectangle(l, b):
    area=l*b
    return area
result= area_rectangle(2,4)
print(result)
