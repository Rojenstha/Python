name=input("Enter your name:")
n=int(input("Enter the times your want to print:"))
i=1
while i<=n:
    print("Your name is",name)
    i+=1
