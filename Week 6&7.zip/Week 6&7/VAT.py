cp=int(input("Enter enter the cost price:"))
vat=0.13
Va= vat*cp
print("The VAT amount is %f"%Va)
