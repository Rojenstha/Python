def name(fname,lname):
    print(fname,lname)
f=input("Enter first name:")
l=input("Enter last name:")
name(f,l)
