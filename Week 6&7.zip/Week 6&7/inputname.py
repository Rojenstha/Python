fname=input("Enter your first name:")
lname=input("Enter your last name:")
print("Your fullname is",fname,lname)

