def your_name(fname,mname,lname):
    return fname+" "+mname+" "+lname
f=input("Enter first name:")
m=input("Enter middle name:")
l=input("Enter last name:")
print("Your fullname is ",your_name(f,m,l))
