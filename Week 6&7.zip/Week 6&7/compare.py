num= int(input("Enter the number between 0-100:"))
if (num>=0):
    print("Within range.")
elif (num>100):
    print("Out of range.")
else:
    print("Out of range.")
