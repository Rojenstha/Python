i=50
sum=0
while i>0:
    sum=sum+i
    i-=1
    print(sum)
