r=100

lb= 300
total= lb+(4*r)
print("The total amount spent is",total)

