a=int(input("Enter your age:"))
if(a>=18):
    print("You can Vote.")
else:
    print("You cannot vote.")
