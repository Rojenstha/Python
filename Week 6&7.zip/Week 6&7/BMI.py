w= int(input("Enter the weight in kg:"))
h = int(input("Enter the height in cm:"))
bmi = w/(h**2)
print("The body mass index is ",bmi)
