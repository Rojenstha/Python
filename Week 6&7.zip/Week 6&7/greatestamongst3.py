a=int(input("Enter the 1st number:"))
b=int(input("Enter the 2nd number:"))
c=int(input("Enter the 3rd number:"))
if(a>b and a>c):
    print(a,"is the greastest.")
if(b>a and b>c):
    print(b,"is the greatest.")
if(c>a and c>b):
    print(c,"is the greatest.")

