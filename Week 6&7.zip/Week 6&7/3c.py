num=int(input("Enter the number of credit:"))
if num>=90:
    print("Senior Status.")
elif num>=60:
    print("Junior Status.")
elif num>=30:
    print("Sophomore Status.")
else:
    print("Freshman Status.")
