def avg(a,b):
    return (a+b)/2
print(avg(2,3))
