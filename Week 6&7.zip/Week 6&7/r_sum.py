def sum(a,b,c,d):
    s=a+b+c+d
    return s
print("The sum is",sum(2,3,4,6))
